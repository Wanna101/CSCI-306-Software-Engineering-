/**
 * 
 */

import java.util.*;
import java.io.*;

/**
 * @author davidyoung
 *
 */
public class NegativeBalanceException extends Exception {
	
	
	private double negativeBalance;
	
	public NegativeBalanceException() {
		super("Error: negative balance");
	}
	
	public NegativeBalanceException(double negativeBalance) {
		super("Amount exceeds balance by " + negativeBalance);
		this.negativeBalance = negativeBalance;
		// write message to log file, i.e. logfile.txt
		try {
			FileWriter fileWriter = new FileWriter("logfile.txt");
			PrintWriter printWriter = new PrintWriter(fileWriter);
			printWriter.print("Amount exceeds balance by " + negativeBalance);
			
			printWriter.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	@Override
	public String toString() {
		return "Balance of " + negativeBalance + " not allowed";
	}
	
	
	
	
}
