David Young
CSCI306 Section C

Time Taken: less than an hour