import java.io.IOException;

/**
 * 
 */

/**
 * @author davidyoung
 *
 */

public class BankAccount {

	private double balance;
	
	public BankAccount(double balance) {
		this.balance = balance;
	}
	
	public double withdraw(double amount) throws NegativeBalanceException {
		
		// needs throws clause somewhere
		
		if (amount > balance) {
			// TODO: throws NegativeBalanceException, pass in negative balance
			throw new NegativeBalanceException(balance -= amount);
		} else {
			// update balance
			balance -= amount;
			
		}
		return balance;
	}
	
	public double quickWithdraw(double amount) throws NegativeBalanceException {
		
		// needs throws clause somewhere
		
		if (amount > balance) {
			// TODO: throws NegativeBalanceException with no parameters
			throw new NegativeBalanceException();
		} else {
			// update balance
			balance -= amount;
		}
		return balance;
	}
	
}
