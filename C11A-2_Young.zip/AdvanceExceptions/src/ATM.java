
public class ATM {
	
	BankAccount bankAccount;
	
	public ATM() {
		bankAccount = new BankAccount(500);
		
	}
	
	public void handleTransactions() {
		try {
			double test = bankAccount.withdraw(600);
		} catch (NegativeBalanceException e) {
			// TODO Auto-generated catch block
			// e.printStackTrace();
			System.out.println(e);
			System.out.println(e.getMessage());
		}
		try {
			double test = bankAccount.quickWithdraw(600);
		} catch (NegativeBalanceException e) {
			// TODO Auto-generated catch block
			// e.printStackTrace();
			System.out.println(e);
			System.out.println(e.getMessage());
		}
		 
	}
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		ATM atm = new ATM();
		atm.handleTransactions();
	}

}
