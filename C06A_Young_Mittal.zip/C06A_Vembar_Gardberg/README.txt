Names: Isaac Gardberg, Keshav Vembar

Collaborators: None

Challenges: 
	There was a great deal of misunderstanding and confusion regarding the git log, this lead to several actions being taken that were not supposed to be, this was releived by
a communication with the TAs.

Likes:
	We liked the usage of enumerated types, they are quite interesting and enjoyable.

Dislikes:
	We did not enjoy the git aspect of the assignment as it was quite confusing and aggrivating, this should have been explained better in class.

Time taken: 70 minutes

Time taken regardingin git: 120 minutes

Notes:
	Git was not the most easy thing to use.