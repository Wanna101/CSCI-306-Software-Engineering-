/**
 * Burner class. 
 *  
 * @author Isaac Gardberg
 * @author Keshav Vembar
 * 
 * Purpose: Simulates a burner on a stove
 */

public class Burner {
	//The Temperature enumerated type is used myTemperature which holds the temperature of the burner
	public enum Temperature {BLAZING, HOT, WARM, COLD};
	private Temperature myTemperature;
	//mySetting simply holds the setting that the burner has
	private Setting mySetting;
	//The timer of the burner controls when the temperature changes, the time that this will take is TIME_DURATION
	private int timer = 0;
	public static final int TIME_DURATION = 2;
	
	//This getter method simply returns the myTemperature variable
	public Temperature getMyTemperature() {
		return myTemperature;
	}
	
	//The constructor for burner starts with the burners being off and cold.
	public Burner() {
		super();
		mySetting = Setting.OFF;
		myTemperature = Temperature.COLD;
	}
	
	//This method displays information on the burner
	public String display() {
		//The initial parts of the output are formed here
		String information = mySetting + ".....";
		
		//based on the temperature the message will change.
		switch(myTemperature) {
		
		case COLD:
			information = information + "cooool";
			break;
		case WARM:
			information = information + "warm";
			break;
		case HOT:
			information = information + "CAREFUL";
			break;
		case BLAZING:
			information = information + "VERY HOT! DON'T TOUCH";
			break;
		}
			
		
		return information;
	}
	
	//This function serves the purpose of simulating a plus being hit on the burner
	public void plusButton() {
		//The timer is set to TIME_DURATION as it begins heating up
		timer = TIME_DURATION;
		
		//This switch statement updates the setting by raising it
		switch (mySetting) {
		case OFF:
			mySetting = Setting.LOW;
			return;
		case LOW:
			mySetting = Setting.MEDIUM;
			return;
		case MEDIUM:
			mySetting = Setting.HIGH;
			return;
		case HIGH:
			return;
		}
	}
	
	//This functions serves the purpose of simulating when the minus button is hit
	public void minusButton() {
		//The timer is set to TIME_DURATION to simulate the time taken to cool down
		timer = TIME_DURATION;
		
		//This switch statement adjusts the settings to be lower than they previously were
		switch (mySetting) {
		case LOW:
			mySetting = Setting.OFF;
			return;
		case MEDIUM:
			mySetting = Setting.LOW;
			return;
		case HIGH:
			mySetting = Setting.MEDIUM;
			return;
		case OFF:
			return;
		}
	}
	
	public void updateTemperature() {
		//A single unit of time has passed, so timer is decremented by 1
		timer = timer - 1;
		
		//If timer is not at 0 then the temperature will not change and so the function is simply returned out
		if (timer > 0) {
			return;
		}
		
		//These switch statements adjust the temperature of the burners accordingly based on the setting.
		//This effectively acts as a matrix of outcomes based on the temperature and setting of the burner
		switch (mySetting) {
		
		case OFF:
			switch (myTemperature) {
			case COLD:
				myTemperature = Temperature.COLD;
				return;
			case WARM:
				myTemperature = Temperature.COLD;
				return;
			case HOT:
				myTemperature = Temperature.WARM;
				return;
			case BLAZING:
				myTemperature = Temperature.HOT;
				return;
			}
			return;
		case LOW:
			switch (myTemperature) {
			case COLD:
				myTemperature = Temperature.WARM;
				return;
			case WARM:
				myTemperature = Temperature.WARM;
				return;
			case HOT:
				myTemperature = Temperature.WARM;
				return;
			case BLAZING:
				myTemperature = Temperature.HOT;
				return;
			}
			return;
		case MEDIUM:
			switch (myTemperature) {
			case COLD:
				myTemperature = Temperature.WARM;
				return;
			case WARM:
				myTemperature = Temperature.HOT;
				return;
			case HOT:
				myTemperature = Temperature.HOT;
				return;
			case BLAZING:
				myTemperature = Temperature.HOT;
				return;
			}
			return;
		case HIGH:
			switch (myTemperature) {
			case COLD:
				myTemperature = Temperature.WARM;
				return;
			case WARM:
				myTemperature = Temperature.HOT;
				return;
			case HOT:
				myTemperature = Temperature.BLAZING;
				return;
			case BLAZING:
				myTemperature = Temperature.BLAZING;
				return;
			}
			return;
		}
	}

	//This toString overridden method returns the appropriate information on a burner
	@Override
	public String toString() {
		String message = "";
		
		//the message regarding the temperature depends upon the value of myTemperature
		switch(myTemperature) {
		case COLD:
			message = "cooool";
			break;
		case WARM:
			message = "warm";
			break;
		case HOT:
			message = "CAREFUL";
			break;
		case BLAZING:
			message = "VERY HOT! DON'T TOUCH";
			break;
		}
		
		return mySetting.toString() + "....." + message;
	}
	
}
