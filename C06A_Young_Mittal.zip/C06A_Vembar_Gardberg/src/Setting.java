/**
 * Setting enumerated type. 
 *  
 * @author Isaac Gardberg
 * @author Keshav Vembar
 * 
 * Purpose: Simulates the setting for a Burner
 */

public enum Setting {
	//These are the values that the Setting can be
	OFF("---"), LOW("--+"), MEDIUM("-++"), HIGH("+++");
	
	//This string is the representation of the Setting type
	private String representation;

	//This constructor allows for Setting to be constructed with an appropriate representation
	Setting(String representation) {
		this.representation = representation;
	}
	
	//This toString override returns the proper information concerning the setting, namely its representation
	@Override
	public String toString() {
		return "[" + representation + "]";
	}
	
	
}
