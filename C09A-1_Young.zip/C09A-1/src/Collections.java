/*
 * Author: David Young
 * Class: CSCI306 Section C
 */


import java.util.*;

public class Collections {

	private Map<String, String> mapCourses;
	
	public Collections() {
		// mapCourses = new HashMap<String, String>();
		
		mapCourses = new TreeMap<String, String>();
		// When using a TreeMap, it takes the key values and sorts them in alphabetical order
		// and prints them
		
		// mapCourses = new Map<String, String>();
		// The compiler error I get from changing the Map variable declaration to a Map is 
		// it cannot instantiate the type Map<String, String>. It wont be able to be instantiated
		// because Map is not an actual type
	}
	
	public void getInfo() {
		Scanner in = new Scanner(System.in);
		String name = "";
		String favClass = "";
		do {
			System.out.print("Enter a student followed by a favorite class or Q to quit (i.e. John 306): ");
			name = in.next();
			if (!(name.equalsIgnoreCase("Q"))) {
				favClass = in.next();
				mapCourses.put(name, favClass);
			}
			
		} while (!(name.equalsIgnoreCase("Q")));
	}
	
	public void printInfo() {
		for (String name: mapCourses.keySet()) {
			System.out.println(name + " likes " + mapCourses.get(name));
		}
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Collections c = new Collections();
		c.getInfo();
		c.printInfo();
	}

}
